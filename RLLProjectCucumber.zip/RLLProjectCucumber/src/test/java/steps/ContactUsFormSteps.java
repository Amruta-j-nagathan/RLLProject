package steps;



import org.junit.Assert;




import base.BaseTest;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
//import io.github.bonigarcia.wdm.WebDriverManager;
import pages.ContactUsPage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ContactUsFormSteps extends BaseTest {
	private static final Logger logger = LogManager.getLogger(ContactUsFormSteps.class);
	
	//WebDriver driver = new ChromeDriver();
	ContactUsPage cp = new ContactUsPage(driver);

	@Given("I am on Chilternoak Furniture Homepage")
	public void i_am_on_chilternoak_furniture_homepage() {
		logger.info("Chilternoak Furniture Homepage");
		
		
		
		//WebDriverManager.chromedriver().setup();
		//driver.manage().window().maximize();
		//driver.get("https://www.chilternoakfurniture.co.uk/");
		getBrowser();
	}

	@When("I click on ContactUs link")
	public void i_click_on_contact_us_link() throws InterruptedException {
		
		logger.info("Clicking on ContactUs link");
		Thread.sleep(2000);
		cp.Click_contactUsLink();
	    
	}

	@Then("I will be on ContactUs Page and Capture the title of the page")
	public void i_will_be_on_contact_us_page_and_capture_the_title_of_the_page() {
		
		logger.info("Capturing the title of the page");
		
		System.out.println("title of the is page is : "+ driver.getTitle());
	 
	}

	@Then("I entered name as {string} on the page")
	public void i_entered_name_as_on_the_page(String name) throws InterruptedException {
		logger.info("Entering the name");
	    cp.Give_Name(name);
	}

	@Then("I entered email id as {string} on the page")
	public void i_entered_email_id_as_on_the_page(String email) throws InterruptedException {
		logger.info("Entering the mail");
		cp.give_Email(email);
	    
	}

	@Then("I entered phone no as {string} on the page")
	public void i_entered_phone_no_as_on_the_page(String phone) throws InterruptedException {
		logger.info("Entering the Phone");
	    cp.give_Phone(phone);
	}

	@Then("I entered message as {string} on the page")
	public void i_entered_message_as_on_the_page(String message) throws InterruptedException {
		logger.info("Entering the message");
	    cp.give_Message(message);
	    
	    
	}

	@Then("I click on send button")
	public void i_click_on_send_button() throws InterruptedException {
		logger.info("Click on the send button");
	  cp.Click_Send();
	  Thread.sleep(5000);
	}
	
	@Then("It shoulld diplayed the message {string}")
	public void it_shoulld_diplayed_the_message(String Status) {
		logger.info("Messaged displayed");
		
		/*if (Status.contains("Thanks for contacting us.")) {
            // Add assertion or verification for successful confirmation message
            System.out.println("Thanks for contacting us. We'll get back to you as soon as possible.");
            
            
            
        } else if (Status.contains("Please enter the valid email")){
        	// Add assertion or verification for invalid email
        	System.out.println("Oops, sorry. We were unable to submit your inquiry. Please correct the following and submit again. The email is invalid");
            
        }else {
        	// Add assertion or verification for confirmation message
            // For example, checking error messages or validating the confirmation message
        	//String pageSource = driver.getPageSource();
        	String errorMessage = Status;
        	 Assert.assertTrue(driver.getPageSource().contains(errorMessage));
		
		
        //driver.quit();
    }*/
		
		
			String expected = Status;
			String actualText = cp.validate_Confirmation_Text();
			Assert.assertTrue(actualText.contains(expected));
			
			
		  
	}
}
	    
	


